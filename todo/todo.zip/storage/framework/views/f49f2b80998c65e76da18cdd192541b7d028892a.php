<?php
use App\Models\Task;
use App\Models\User;
?>

<?php if(count($tasks)): ?>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($task->status !== "Отменена"): ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    Задач еще нет. <a data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</a>
<?php endif; ?>

<?php /**PATH C:\OpenServer\domains\localhost\esoft\todo\resources\views/components/card.blade.php ENDPATH**/ ?>