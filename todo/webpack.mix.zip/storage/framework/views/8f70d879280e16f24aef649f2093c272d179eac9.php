<?php
use App\Models\Task;
use App\Models\User;
?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <?php if(isset($tasks) && !isset($responsibleIDs)): ?>
            <div class="card">
                <div class="card-header">Все задачи</div>
                <div class="card-body">
                    <?php if(count($tasks)): ?>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($task->status !== "Отменена"): ?>
                            <div class="card">
                                <div class="card-header <?php if($task->status == 'Выполнена'): ?> <?php echo e('done-task'); ?> <?php elseif($task->deadline < date("Y-n-j")): ?> <?php echo e('overdue-task'); ?> <?php endif; ?>">
                                    <h3 id="name-<?php echo e($task->id); ?>"><?php echo e($task->name); ?></h3>
                                </div>
                                <div class="card-body">
                                    <p>
                                    <h6 id="description-<?php echo e($task->id); ?>" class="card-text"><?php echo e($task->description); ?></h6>
                                    </p>
                                    <div >
                                        <b>Приоритет: </b>
                                        <span id="priority-<?php echo e($task->id); ?>" class="
                                                    <?php if($task->priority ==="Высокий"): ?> red
                                                    <?php elseif($task->priority ==="Средний"): ?> yellow
                                                    <?php else: ?> green
                                                    <?php endif; ?>
                                            "><?php echo e($task->priority); ?></span>
                                    </div>

                                    <div>
                                        <b>Дедлайн:</b>
                                        <span id="deadline-<?php echo e($task->id); ?>"><?php echo e($task->deadline); ?></span>
                                    </div>

                                    <div>
                                        <b>Ответственный:</b>
                                        <?php if($task->responsibleID == Auth::user()->id ): ?>
                                            <span id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>">Я</span>
                                        <?php else: ?>
                                            <a id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>" href="mailto:<?php echo e(User::where('id',$task -> responsibleID)->get()->first()->email); ?>">
                                                <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->surname); ?>

                                                <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->name); ?>

                                                <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->patronymic); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>


                                    <form id="change-status-form-<?php echo e($task->id); ?>" action="<?php echo e(route('changeStatus')); ?>" method="get"  >
                                        <b>Статус:</b>
                                        <select name="status" id="" onchange="document.getElementById('change-status-form-<?php echo e($task->id); ?>').submit();">
                                            <option <?php if($task->status == "К выполнению"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_К выполнению">К выполнению</option>
                                            <option <?php if($task->status == "Выполняется"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_Выполняется">Выполняется</option>
                                            <option <?php if($task->status == "Выполнена"): ?> selected <?php endif; ?>  value="<?php echo e($task->id); ?>_Выполнена">Выполнена</option>
                                        </select>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <br><br>

                                    <?php if($task->creatorID == Auth::user()->id): ?>
                                        <div class="row">
                                            <div class="col">
                                                <button type="button"   data-task-id="<?php echo e($task->id); ?>" class="btn btn-outline-primary trigger-change-task" data-bs-toggle="modal" data-bs-target="#changeTask">Изменить задачу</button>
                                            </div>
                                            <div class="col">
                                                <form id="cancel-task-form" action="<?php echo e(route('cancelTask')); ?>"  >
                                                    <button class="btn btn-outline-danger" name="cancelId"  value="<?php echo e($task->id); ?>" onclick="document.getElementById('cancel-task-form').submit();">Отменить задачу</button>
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        Задач еще нет. <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif(isset($tasks_today)): ?>
            <div class="col-md">

                <div class="card">
                    <div class="card-header">Задачи на сегодня</div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(count($tasks_today)): ?>
                            <?php $__currentLoopData = $tasks_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($task->status !== "Отменена"): ?>
                                    <div class="card">
                                        <div class="card-header <?php if($task->status == 'Выполнена'): ?> <?php echo e('done-task'); ?> <?php elseif($task->deadline < date("Y-n-j")): ?> <?php echo e('overdue-task'); ?> <?php endif; ?>">
                                            <h3 id="name-<?php echo e($task->id); ?>"><?php echo e($task->name); ?></h3>
                                        </div>
                                        <div class="card-body">
                                            <p>
                                            <h6 id="description-<?php echo e($task->id); ?>" class="card-text"><?php echo e($task->description); ?></h6>
                                            </p>
                                            <div >
                                                <b>Приоритет: </b>
                                                <span id="priority-<?php echo e($task->id); ?>" class="
                                                    <?php if($task->priority ==="Высокий"): ?> red
                                                    <?php elseif($task->priority ==="Средний"): ?> yellow
                                                    <?php else: ?> green
                                                    <?php endif; ?>
                                                    "><?php echo e($task->priority); ?></span>
                                            </div>

                                            <div>
                                                <b>Дедлайн:</b>
                                                <span id="deadline-<?php echo e($task->id); ?>"><?php echo e($task->deadline); ?></span>
                                            </div>

                                            <div>
                                                <b>Ответственный:</b>
                                                <?php if($task->responsibleID == Auth::user()->id ): ?>
                                                    <span id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>">Я</span>
                                                <?php else: ?>
                                                    <a id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>" href="mailto:<?php echo e(User::where('id',$task -> responsibleID)->get()->first()->email); ?>">
                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->surname); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->name); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->patronymic); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </div>


                                            <form id="change-status-form-<?php echo e($task->id); ?>" action="<?php echo e(route('changeStatus')); ?>" method="get"  >
                                                <b>Статус:</b>
                                                <select name="status" id="" onchange="document.getElementById('change-status-form-<?php echo e($task->id); ?>').submit();">
                                                    <option <?php if($task->status == "К выполнению"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_К выполнению">К выполнению</option>
                                                    <option <?php if($task->status == "Выполняется"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_Выполняется">Выполняется</option>
                                                    <option <?php if($task->status == "Выполнена"): ?> selected <?php endif; ?>  value="<?php echo e($task->id); ?>_Выполнена">Выполнена</option>
                                                </select>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <br><br>

                                            <?php if($task->creatorID == Auth::user()->id): ?>
                                                <div class="row">
                                                    <div class="col">
                                                        <button type="button"   data-task-id="<?php echo e($task->id); ?>" class="btn btn-outline-primary trigger-change-task" data-bs-toggle="modal" data-bs-target="#changeTask">Изменить задачу</button>
                                                    </div>
                                                    <div class="col">
                                                        <form id="cancel-task-form" action="<?php echo e(route('cancelTask')); ?>"  >
                                                            <button class="btn btn-outline-danger" name="cancelId"  value="<?php echo e($task->id); ?>" onclick="document.getElementById('cancel-task-form').submit();">Отменить задачу</button>
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                                Задач еще нет. <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</button>
                            <?php endif; ?>

                    </div>
                </div>
            </div>
            <div class="col-md">
                <div class="card">
                    <div class="card-header">Задачи на неделю</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(count($tasks_week)): ?>
                            <?php $__currentLoopData = $tasks_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($task->status !== "Отменена"): ?>
                                    <div class="card">
                                        <div class="card-header
                                                <?php if($task->status == 'Выполнена'): ?> <?php echo e('done-task'); ?> <?php elseif($task->deadline < date("Y-n-j")): ?> <?php echo e('overdue-task'); ?> <?php endif; ?>">
                                            <h3 id="name-<?php echo e($task->id); ?>"><?php echo e($task->name); ?></h3>
                                        </div>
                                        <div class="card-body">
                                            <p>
                                            <h6 id="description-<?php echo e($task->id); ?>" class="card-text"><?php echo e($task->description); ?></h6>
                                            </p>
                                            <div >
                                                <b>Приоритет: </b>
                                                <span id="priority-<?php echo e($task->id); ?>" class="
                                                    <?php if($task->priority ==="Высокий"): ?> red
                                                    <?php elseif($task->priority ==="Средний"): ?> yellow
                                                    <?php else: ?> green
                                                    <?php endif; ?>
                                                    "><?php echo e($task->priority); ?></span>
                                            </div>

                                            <div>
                                                <b>Дедлайн:</b>
                                                <span id="deadline-<?php echo e($task->id); ?>"><?php echo e($task->deadline); ?></span>
                                            </div>

                                            <div>
                                                <b>Ответственный:</b>
                                                <?php if($task->responsibleID == Auth::user()->id ): ?>
                                                    <span id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>">Я</span>
                                                <?php else: ?>
                                                    <a id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>" href="mailto:<?php echo e(User::where('id',$task -> responsibleID)->get()->first()->email); ?>">
                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->surname); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->name); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->patronymic); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </div>


                                            <form id="change-status-form-<?php echo e($task->id); ?>" action="<?php echo e(route('changeStatus')); ?>" method="get"  >
                                                <b>Статус:</b>
                                                <select name="status" id="" onchange="document.getElementById('change-status-form-<?php echo e($task->id); ?>').submit();">
                                                    <option <?php if($task->status == "К выполнению"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_К выполнению">К выполнению</option>
                                                    <option <?php if($task->status == "Выполняется"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_Выполняется">Выполняется</option>
                                                    <option <?php if($task->status == "Выполнена"): ?> selected <?php endif; ?>  value="<?php echo e($task->id); ?>_Выполнена">Выполнена</option>
                                                </select>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <br><br>

                                            <?php if($task->creatorID == Auth::user()->id): ?>
                                                <div class="row">
                                                    <div class="col">
                                                        <button type="button"   data-task-id="<?php echo e($task->id); ?>" class="btn btn-outline-primary trigger-change-task" data-bs-toggle="modal" data-bs-target="#changeTask">Изменить задачу</button>
                                                    </div>
                                                    <div class="col">
                                                        <form id="cancel-task-form" action="<?php echo e(route('cancelTask')); ?>"  >
                                                            <button class="btn btn-outline-danger" name="cancelId"  value="<?php echo e($task->id); ?>" onclick="document.getElementById('cancel-task-form').submit();">Отменить задачу</button>
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                                Задач еще нет. <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md">
                <div class="card">
                    <div class="card-header">Задачи на будущее</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(count($tasks_future)): ?>
                            <?php $__currentLoopData = $tasks_future; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($task->status !== "Отменена"): ?>
                                    <div class="card">
                                        <div class="card-header <?php if($task->status == 'Выполнена'): ?> <?php echo e('done-task'); ?> <?php elseif($task->deadline < date("Y-n-j")): ?> <?php echo e('overdue-task'); ?> <?php else: ?> 123 <?php endif; ?>">
                                            <h3 id="name-<?php echo e($task->id); ?>"><?php echo e($task->name); ?></h3>
                                        </div>
                                        <div class="card-body">
                                            <p>
                                            <h6 id="description-<?php echo e($task->id); ?>" class="card-text"><?php echo e($task->description); ?></h6>
                                            </p>
                                            <div >
                                                <b>Приоритет: </b>
                                                <span id="priority-<?php echo e($task->id); ?>" class="
                                                    <?php if($task->priority ==="Высокий"): ?> red
                                                    <?php elseif($task->priority ==="Средний"): ?> yellow
                                                    <?php else: ?> green
                                                    <?php endif; ?>
                                                    "><?php echo e($task->priority); ?></span>
                                            </div>

                                            <div>
                                                <b>Дедлайн:</b>
                                                <span id="deadline-<?php echo e($task->id); ?>"><?php echo e($task->deadline); ?></span>
                                            </div>

                                            <div>
                                                <b>Ответственный:</b>
                                                <?php if($task->responsibleID == Auth::user()->id ): ?>
                                                    <span id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>">Я</span>
                                                <?php else: ?>
                                                    <a id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>" href="mailto:<?php echo e(User::where('id',$task -> responsibleID)->get()->first()->email); ?>">
                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->surname); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->name); ?>

                                                        <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->patronymic); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </div>


                                            <form id="change-status-form-<?php echo e($task->id); ?>" action="<?php echo e(route('changeStatus')); ?>" method="get"  >
                                                <b>Статус:</b>
                                                <select name="status" id="" onchange="document.getElementById('change-status-form-<?php echo e($task->id); ?>').submit();">
                                                    <option <?php if($task->status == "К выполнению"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_К выполнению">К выполнению</option>
                                                    <option <?php if($task->status == "Выполняется"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_Выполняется">Выполняется</option>
                                                    <option <?php if($task->status == "Выполнена"): ?> selected <?php endif; ?>  value="<?php echo e($task->id); ?>_Выполнена">Выполнена</option>
                                                </select>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <br><br>

                                            <?php if($task->creatorID == Auth::user()->id): ?>
                                                <div class="row">
                                                    <div class="col">
                                                        <button type="button"   data-task-id="<?php echo e($task->id); ?>" class="btn btn-outline-primary trigger-change-task" data-bs-toggle="modal" data-bs-target="#changeTask">Изменить задачу</button>
                                                    </div>
                                                    <div class="col">
                                                        <form id="cancel-task-form" action="<?php echo e(route('cancelTask')); ?>"  >
                                                            <button class="btn btn-outline-danger" name="cancelId"  value="<?php echo e($task->id); ?>" onclick="document.getElementById('cancel-task-form').submit();">Отменить задачу</button>
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                                Задач еще нет. <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</button>
                            <?php endif; ?>

                    </div>
                </div>
            </div>
        <?php elseif(isset($responsibleIDs)): ?>
            <?php $__currentLoopData = $responsibleIDs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ID): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md">
                    <div class="card">
                        <div class="card-header">
                            Ответственный пользователь:
                            <?php if($ID == Auth::user()->id): ?>
                                Я
                            <?php else: ?>
                            <?php echo e(User::where('id',"=",$ID)->get()->first()->surname); ?> <?php echo e(User::where('id',"=",$ID)->get()->first()->name); ?>

                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(count($all_tasks)): ?>
                                <?php $__currentLoopData = $all_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($task->status !== "Отменена" && $task->responsibleID == $ID): ?>
                                        <div class="card">
                                            <div class="card-header <?php if($task->status == 'Выполнена'): ?> <?php echo e('done-task'); ?> <?php elseif($task->deadline < date("Y-n-j")): ?> <?php echo e('overdue-task'); ?> <?php endif; ?>">
                                                <h3 id="name-<?php echo e($task->id); ?>"><?php echo e($task->name); ?></h3>
                                            </div>
                                            <div class="card-body">
                                                <p>
                                                <h6 id="description-<?php echo e($task->id); ?>" class="card-text"><?php echo e($task->description); ?></h6>
                                                </p>
                                                <div >
                                                    <b>Приоритет: </b>
                                                    <span id="priority-<?php echo e($task->id); ?>" class="
                                                    <?php if($task->priority ==="Высокий"): ?> red
                                                    <?php elseif($task->priority ==="Средний"): ?> yellow
                                                    <?php else: ?> green
                                                    <?php endif; ?>
                                                        "><?php echo e($task->priority); ?></span>
                                                </div>

                                                <div>
                                                    <b>Дедлайн:</b>
                                                    <span id="deadline-<?php echo e($task->id); ?>"><?php echo e($task->deadline); ?></span>
                                                </div>

                                                <div>
                                                    <b>Ответственный:</b>
                                                    <?php if($task->responsibleID == Auth::user()->id ): ?>
                                                        <span id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>">Я</span>
                                                    <?php else: ?>
                                                        <a id="responsible-<?php echo e($task->id); ?>" data-responsible-id="<?php echo e($task -> responsibleID); ?>" href="mailto:<?php echo e(User::where('id',$task -> responsibleID)->get()->first()->email); ?>">
                                                            <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->surname); ?>

                                                            <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->name); ?>

                                                            <?php echo e(User::where('id',$task -> responsibleID)->get()->first()->patronymic); ?>

                                                        </a>
                                                    <?php endif; ?>
                                                </div>


                                                <form id="change-status-form-<?php echo e($task->id); ?>" action="<?php echo e(route('changeStatus')); ?>" method="get"  >
                                                    <b>Статус:</b>
                                                    <select name="status" id="" onchange="document.getElementById('change-status-form-<?php echo e($task->id); ?>').submit();">
                                                        <option <?php if($task->status == "К выполнению"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_К выполнению">К выполнению</option>
                                                        <option <?php if($task->status == "Выполняется"): ?> selected <?php endif; ?> value="<?php echo e($task->id); ?>_Выполняется">Выполняется</option>
                                                        <option <?php if($task->status == "Выполнена"): ?> selected <?php endif; ?>  value="<?php echo e($task->id); ?>_Выполнена">Выполнена</option>
                                                    </select>
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                                <br><br>

                                                <?php if($task->creatorID == Auth::user()->id): ?>
                                                    <div class="row">
                                                        <div class="col">
                                                            <button type="button"   data-task-id="<?php echo e($task->id); ?>" class="btn btn-outline-primary trigger-change-task" data-bs-toggle="modal" data-bs-target="#changeTask">Изменить задачу</button>
                                                        </div>
                                                        <div class="col">
                                                            <form id="cancel-task-form" action="<?php echo e(route('cancelTask')); ?>"  >
                                                                <button class="btn btn-outline-danger" name="cancelId"  value="<?php echo e($task->id); ?>" onclick="document.getElementById('cancel-task-form').submit();">Отменить задачу</button>
                                                                <?php echo csrf_field(); ?>
                                                            </form>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Задач еще нет. <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addTask">Создать новую?</button>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        <div class="modal fade" id="changeTask" tabindex="-1" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Изменить задачу</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="get" action="<?php echo e(route('cahangeTask')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">


                            <div class="form-group row">
                                <label for="name"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Название')); ?></label>

                                <div class="col-md-6">
                                    <input id="name-change" type="text"
                                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="name-change" value="<?php echo e(old('name')); ?>" required
                                           autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="description"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Описание')); ?></label>

                                <div class="col-md-6">
                                    <input id="description-change" type="text"
                                           class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="description" value="<?php echo e(old('description')); ?>" required
                                           autocomplete="description" autofocus>

                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="deadline"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Дедлайн')); ?></label>

                                <div class="col-md-6">
                                    <input id="deadline-change" type="date"
                                           class="form-control <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="deadline" value="<?php echo e(old('deadline')); ?>"
                                           autocomplete="deadline" autofocus>

                                    <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="priority"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Приоритет')); ?></label>

                                <div class="col-md-6" id="priority-change">
                                    <select name="priority-change"
                                            class="form-select form-select-lg mb-3">
                                        <option value="Низкий" class="green">Низкий</option>
                                        <option value="Средний" class="yellow">Средний</option>
                                        <option value="Высокий" class="red">Высокий</option>
                                    </select>
                                    <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="responsibleID"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ответственный')); ?></label>

                                <div class="col-md-6" id="responsible-change">
                                    <select name="responsibleID" class="form-select form-select-lg mb-3"
                                            aria-label=".form-select-lg example">
                                        <option value="<?php echo e(Auth::user()->id); ?>">Я</option>
                                        <?php $__currentLoopData = $subordinates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subordinate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($subordinate->id); ?>"><?php echo e($subordinate->surname); ?> <?php echo e($subordinate->name); ?> <?php echo e($subordinate->patronymic); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>


                                    <?php $__errorArgs = ['supervisor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Закрыть
                            </button>
                            <button type="submit" class="btn btn-outline-primary" id="change-values" name="change-id">Изменить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\esoft\todo\resources\views/home.blade.php ENDPATH**/ ?>